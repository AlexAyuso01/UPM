/*
 * Número de móviles, de campos y tamaño del buffer
 */
#define NM 50
#define NC 6
#define MAXB 2500

int vect_movil(int top, const char *sfmt[], const char *vmov[NM][NC]);
